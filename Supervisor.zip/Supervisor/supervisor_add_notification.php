<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-add'] )) {
	$content = mysql_real_escape_string ( $_POST ['content'] );
	$group_id = mysql_real_escape_string ( $_GET ['group_id'] );
	
	if (mysql_query ( "INSERT INTO notifications(content, group_id) VALUES('$content', '$group_id')" )) {
		echo "<script>alert('successfully Add the notification');</script>";
		header ( "REFRESH:0; url=supervisor_show_group_notifications.php?id=$_GET[group_id]" );
	} else {
		echo "<script>alert('error while adding notification ...');</script>";
	}
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Add <span> Notification </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<th>Content</th>
					<td>
						<textarea name="content" rows="5" placeholder="notification content" required class="form-control"></textarea>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-add'
						value=' &nbsp;&nbsp; Add &nbsp;&nbsp; ' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>