<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	$file = $_FILES ["report_file"] ["name"];
	
	if (($_FILES ["report_file"] ["type"] == "application/pdf") && ($_FILES ["report_file"] ["size"] < 2000000)) {
		// if there is an error in upload files
		if ($_FILES ["report_file"] ["error"] > 0) {
			echo "Error: " . $_FILES ["report_file"] ["error"] . "<br>";
		} else // there is no errors in uploading files
{
			// save the file in the file folder
			move_uploaded_file ( $_FILES ["report_file"] ["tmp_name"], "reports/" . $_FILES ["report_file"] ["name"] );
			
			if (mysql_query ( "UPDATE groups SET report_file = '$file' WHERE id = '$_GET[id]'" )) {
				?>

<script>alert('successfully Add the report');</script>
<?php
				header ( "REFRESH:0; url=supervisor_show_groups.php#content" );
			} else {
				echo "<script>alert('error while adding report');</script>";
			}
		}
	} else {
		?>
<script>alert('error while adding report check the file type and size PDF and 2 mega ...');</script>
<?php
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> Report </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post" enctype="multipart/form-data">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td><input type="file" name="report_file" required
						class="form-control" /></td>
				</tr>
				<tr>
					<td align="center"><input type='submit' name='btn-signup'
						value='Add Report' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>

<?php include 'footer.php';?>