<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
	border: 1px solid #ccc;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<div class="title-area">
	<h2 class="tittle">
		Group <span> Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<p align="right">
	<a href="#" onclick="window.print();"><img src="assets/images/printer.png" width="45" height="45" /></a>
</p>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<?php
		$evaluation_query = "SELECT evaluation.*, evaluation_criteria.criteria , evaluation_criteria.category 
							FROM evaluation 
							LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id 
							WHERE evaluation.student_id IN ( SELECT id FROM student WHERE group_id = '$_GET[id]' ) 
							AND evaluation.examiner_id = '$_SESSION[user_id]' 
							AND evaluation.evaluation_criteria_id NOT IN (1, 2, 3, 4)
							GROUP BY evaluation.evaluation_criteria_id";
		$evaluation = mysql_query ( $evaluation_query ) or die ( "error evaluation " . mysql_error () );
		
		if (mysql_num_rows ($evaluation) != 0) {  ?>
	<tr>
		<th>Evaluation Criteria</th>
		<th>Criteria Category</th>
		<th>Grad</th>
	</tr>
		<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) { 
			$status = $evaluation_row['status'];?>
			<tr>
				<td><?php echo $evaluation_row['criteria']?></td>
				<td><?php echo $evaluation_row['category']?></td>
				<td><?php echo $evaluation_row['grade']?></td>
			</tr>
	<?php } // while		
			// check for update
			if ($status == "Pending") {
				echo "<tr>
						<td align='center' colspan='3'>
							<a href='supervisor_update_group_evaluation.php?group_id=$_GET[id]'>Update Group Evaluation</a>
						</td>
					</tr>";
			}	// pending
		} // if num rows
		else {
			// show the evaluate link
			echo "<tr>
					<td align='center'>
						<a href='supervisor_evaluate_group.php?group_id=$_GET[id]'>Evaluate this group</a>
					</td>
				</tr>";
		} ?>
</table>

<br/>
<br/>

<div class="title-area">
	<h2 class="tittle">
		Individual <span> Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<?php
$student = mysql_query ( "select * FROM student WHERE group_id = '$_GET[id]'" ) or die ( "error student " . mysql_error () );
?>

<?php while ($student_row = mysql_fetch_array ( $student )) {?>
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<td colspan="2" align="center"><strong><?php echo $student_row['name']; ?></strong></td>
		</tr>
		<?php  $evaluation = mysql_query ( "select evaluation.*, evaluation_criteria.criteria FROM evaluation LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id WHERE evaluation.student_id = '$student_row[id]' AND evaluation.examiner_id = '$_SESSION[user_id]' AND evaluation.evaluation_criteria_id IN (1, 2, 3, 4)" ) or die ( "error student " . mysql_error () ); ?>
		<?php  if (mysql_num_rows ($evaluation) != 0) {  ?>
		<tr>
			<th>Evaluation Criteria</th>
			<th>Grad</th>
		</tr>
			<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) { 
				$status = $evaluation_row['status'];?>
				<tr>
					<td><?php echo $evaluation_row['criteria']?></td>
					<td><?php echo $evaluation_row['grade']?></td>
				</tr>
		<?php } // while		
				// check for update
				if ($status == "Pending") {
					echo "<tr><td align='center' colspan='2'><a href='supervisor_update_student_evaluation.php?student_id=$student_row[id]'>Update Evaluation</a></td></tr>";
				}	// pending
			} // if num rows
			else {
				// show the evaluate link
				echo "<tr><td align='center'><a href='supervisor_evaluate_student.php?student_id=$student_row[id]'>Evaluate this student</a></td></tr>";
			} ?>
	</table>
	<br/>
<?php }?>

<?php include 'footer.php'; ?>