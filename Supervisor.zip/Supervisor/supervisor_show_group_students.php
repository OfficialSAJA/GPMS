<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<div class="title-area">
	<h2 class="tittle">
		Group <span> Students </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $students = mysql_query ( "select * FROM student WHERE group_id = '$_GET[id]'" ) or die ("error students " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Name</th>
		<th>Username</th>
		<th>Email</th>
		<th>Mobile</th>
		<th></th>
	</tr>
	<?php while ($student_row = mysql_fetch_array ( $students )) { ?>
		<tr>
		<td><?php echo $student_row['name']?></td>
		<td><?php echo $student_row['username']?></td>
		<td><?php echo $student_row['email']?></td>
		<td><?php echo $student_row['mobile']?></td>
	</tr>
		<?php }?>		 
</table>

<?php include 'footer.php'; ?>