<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<style>
td, th, table {
	text-align: center;
	border: 1px solid #ccc;
}

th {
	background-color: #eee;
}
</style>


<?php
if (isset ( $_POST ['btn-signup'] )) {
	$evaluation_criteria_id = $_POST['evaluation_criteria_id'];
	$grade = $_POST['grade'];
	$student_id = $_GET['student_id'];
	$examiner_id = $_SESSION['user_id'];
	
	$count = 0;
	// get group students
	$students = mysql_query ( "select * FROM student WHERE group_id = '$_GET[group_id]'" ) or die ( "error students " . mysql_error () );
	
	while ($student_row = mysql_fetch_array ( $students )) {
		// loop through the evaluations
		for($i = 0; $i < count ($evaluation_criteria_id); $i++) {
			$evaluation_result = mysql_query ( "INSERT INTO evaluation (evaluation_criteria_id, grade, student_id, examiner_id) 
			VALUES('$evaluation_criteria_id[$i]', '$grade[$i]', '$student_row[id]', '$examiner_id')" );
			$count += 1;
		}
	}
		
	if ($count != 0) {
		echo "<script>alert('successfully Add the group evaluation');</script>";
		header ( "REFRESH:0; url=supervisor_show_group_evaluation.php?id=$_GET[group_id]" );
	} else {
		echo "<script>alert('error while adding group evaluation ...');</script>";
		header ( "REFRESH:0; url=supervisor_show_group_evaluation.php?id=$_GET[group_id]" );
	}
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Add <span> Group Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<?php $evaluates = mysql_query ( "select * FROM evaluation_criteria WHERE supervisor = 'yes' AND active = 'yes' AND category != 'individual' ORDER BY category" ) or die ("error evaluates " . mysql_error()); ?>

<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="70%" border="0" id="form_table">
				<tr>
					<th>Criteria</th>
					<th>Max Grade</th>
					<th>Category</th>
					<th>Your Grade</th>
				</tr>
				<?php while ($evaluate_row = mysql_fetch_array ( $evaluates )) { ?>
					<input type="hidden" name="evaluation_criteria_id[]" value="<?php echo $evaluate_row['id']?>" />
					<tr>
						<td><?php echo $evaluate_row['criteria']?></td>
						<td><?php echo $evaluate_row['max_grade']?></td>
						<td><?php echo $evaluate_row['category']?></td>
						<td><input type="number" name="grade[]" placeholder="Grade" min="1" max="<?php echo $evaluate_row['max_grade']?>" required class="form-control" /></td>
					</tr>
				<?php } ?>
				<tr>
					<td align="center" colspan="4">
						<input type='submit' name='btn-signup' value='Add Group Evaluation' class="btn btn-primary" />
					</td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>