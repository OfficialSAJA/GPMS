<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	$title = mysql_real_escape_string ( $_POST ['title'] );
	$deadline = mysql_real_escape_string ( $_POST ['deadline'] );
	
// 	echo "INSERT INTO tasks (title, group_id) VALUES('$title', $_GET[id]])";
	
	if (mysql_query ( "INSERT INTO tasks (title, deadline, group_id) VALUES('$title', '$deadline', '$_GET[id]')" )) {
		?>
<script>alert('successfully Add the task');</script>
<?php header ( "REFRESH:0; url=supervisor_show_group_tasks.php?id=$_GET[id]#content" );?>
<?php
	} else {
		?>
<script>alert('error while adding task ...');</script>
<?php header ( "REFRESH:0; url=supervisor_show_group_tasks.php?id=$_GET[id]#content" );?>
<?php
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> task </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td>Title : <input type="text" name="title" placeholder="Task Title"
						required class="form-control" /></td>
				</tr>
				<tr>
					<td>Deadline : <input type="date" name="deadline" placeholder="Task Deadline"
						required class="form-control" min="<?php echo date('Y-m-d'); ?>" /></td>
				</tr>
				<tr>
					<td align="center"><input type='submit' name='btn-signup'
						value='Add Task' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>