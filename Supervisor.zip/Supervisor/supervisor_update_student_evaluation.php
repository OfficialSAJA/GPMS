<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "supervisor") {
	header ( "Location: index.php" );
}
?>

<style>
td, th, table {
	text-align: center;
	border: 1px solid #ccc;
}

th {
	background-color: #eee;
}
</style>


<?php
if (isset ( $_POST ['btn-signup'] )) {
	$evaluation_criteria_id = $_POST['evaluation_criteria_id'];
	$grade = $_POST['grade'];
	$student_id = $_GET['student_id'];
	$examiner_id = $_SESSION['user_id'];
	
	// delete the evaluation 
	mysql_query ("DELETE FROM evaluation WHERE student_id = '$student_id' AND examiner_id = '$examiner_id' AND evaluation_criteria_id IN (1, 2, 3, 4)") or die ("error update " . mysql_error ());
	
	// loop through the evaluations
	$count = 0;
	for($i = 0; $i < count ($evaluation_criteria_id); $i++) {
		$evaluation_result = mysql_query ( "INSERT INTO evaluation (evaluation_criteria_id, grade, student_id, examiner_id) 
		VALUES('$evaluation_criteria_id[$i]', '$grade[$i]', '$student_id', '$examiner_id')" );
		$count += 1;
	}
		
	if ($count != 0) {
		?>
<script>alert('successfully Update the evaluation');</script>
<?php header ( "REFRESH:0; url=supervisor_show_groups.php" );?>
<?php
	} else {
		?>
<script>alert('error while update evaluation ...');</script>
<?php header ( "REFRESH:0; url=supervisor_show_groups.php" );?>
<?php
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Update <span> Student Evaluation</span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<?php $evaluates = mysql_query ( "select * FROM evaluation_criteria WHERE examiner = 'yes' AND active = 'yes' AND category = 'individual'" ) or die ("error evaluates " . mysql_error()); ?>

<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="70%" border="0" id="form_table">
				<tr>
					<th>Criteria</th>
					<th>Max Grade</th>
					<th>Category</th>
					<th>Your Grade</th>
				</tr>
				<?php while ($evaluate_row = mysql_fetch_array ( $evaluates )) { ?>
					<input type="hidden" name="evaluation_criteria_id[]" value="<?php echo $evaluate_row['id']?>" />
					<tr>
						<td><?php echo $evaluate_row['criteria']?></td>
						<td><?php echo $evaluate_row['max_grade']?></td>
						<td><?php echo $evaluate_row['category']?></td>
						<td><input type="number" name="grade[]" placeholder="Grade" min="1" max="<?php echo $evaluate_row['max_grade']?>" required class="form-control" /></td>
					</tr>
				<?php } ?>
				<tr>
					<td align="center" colspan="4">
						<input type='submit' name='btn-signup' value='Update Evaluation' class="btn btn-primary" />
					</td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>