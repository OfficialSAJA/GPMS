<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
	border: 1px solid #ccc;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Your <span> Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<p align="right">
	<a href="#" onclick="window.print();"><img src="assets/images/printer.png" width="45" height="45" /></a>
</p>
<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<?php
			$total = 0;
			
			$examiners = mysql_query ("select session.*, examiner1.name AS examiner1_name, examiner2.name AS examiner2_name , examiner3.name AS examiner3_name 
										FROM session
										LEFT JOIN member AS examiner1 ON session.examiner1_id = examiner1.id
										LEFT JOIN member AS examiner2 ON session.examiner2_id = examiner2.id
										LEFT JOIN member AS examiner3 ON session.examiner3_id = examiner3.id
										WHERE session.group_id = '$_SESSION[group_id]'") or die ("error examiners " . mysql_error ());
			
			$examiner = mysql_fetch_array ($examiners); ?>
			
			<?php $evaluation = mysql_query ( "select SUM(grade)*0.2 AS total FROM evaluation WHERE student_id = '$_SESSION[user_id]' AND examiner_id = '$examiner[examiner1_id]'" ) or die ( "error student " . mysql_error () ); ?>
			<?php $evaluation_row = mysql_fetch_array ($evaluation); 
					$total += $evaluation_row['total'];?>

			<?php $evaluation = mysql_query ( "select SUM(grade)*0.2 AS total FROM evaluation WHERE student_id = '$_SESSION[user_id]' AND examiner_id = '$examiner[examiner2_id]'" ) or die ( "error student " . mysql_error () ); ?>
			<?php $evaluation_row = mysql_fetch_array ($evaluation); 
					$total += $evaluation_row['total'];?>

			<?php $evaluation = mysql_query ( "select SUM(grade)*0.6 AS total FROM evaluation WHERE student_id = '$_SESSION[user_id]' AND examiner_id = '$examiner[examiner3_id]'" ) or die ( "error student " . mysql_error () ); ?>
			<?php $evaluation_row = mysql_fetch_array ($evaluation); 
					$total += $evaluation_row['total'];?>
				
			<tr>
				<td colspan="2" align="center"><strong>Your Total Evaluation : <?php echo $total; ?></strong></td>
			</tr>
	</table>
<br/>
<br/>
<?php include 'footer.php'; ?>