<?php include 'header.php'; ?>

 <div class="title-area">
	<h2 class="tittle">
		Edit <span> Profile </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-update'] )) {
	$name = mysql_real_escape_string ( $_POST ['name'] );
	$uname = mysql_real_escape_string ( $_POST ['uname'] );
	$email = mysql_real_escape_string ( $_POST ['email'] );
	$mobile = mysql_real_escape_string ( $_POST ['mobile'] );
	$upass = (mysql_real_escape_string ( $_POST ['pass'] ));
	
	if (mysql_query ( "UPDATE student SET name = '$name', username = '$uname', password = '$upass', email = '$email', mobile = '$mobile' WHERE id = $_SESSION[user_id]" )) {
		?>
<script>alert('successfully updated ');</script>
<?php header ( "REFRESH:0; url=member_account.php#content" );?>
<?php
	} else {
		?>
<script>alert('error while updating data ...');</script>
<?php
	}
}
?>

<?php
// if the user is loggedin
$query = "SELECT * FROM student WHERE id = $_SESSION[user_id]";
$member_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$member_row = mysql_fetch_array ( $member_result );

if (mysql_num_rows ( $member_result ) == 1) {
	?>
<center>
	<form method="post">
		<table align="center" width="50%" border="0" id="form_table">
			<tr>
				<td>Name : </td><td><input type="text" name="name"
					placeholder="member name" required
					value="<?php echo $member_row['name'];?>" class="form-control"></td>
			</tr>			<tr>
				<td>Username : </td><td><input type="text" name="uname"
					placeholder="member username" required
					value="<?php echo $member_row['username'];?>" class="form-control"></td>
			</tr>
			<tr>
				<td>Email : </td><td><input type="email" name="email"
					placeholder="member Email" required
					value="<?php echo $member_row['email'];?>" class="form-control" /></td>
			</tr>
			<tr>
				<td>Password : </td><td><input type="password" name="pass"
					placeholder="member Password" required
					value="<?php echo $member_row['password'];?>" class="form-control" /></td>
			</tr>
			<tr>
				<td>Mobile : </td><td><input type="text" name="mobile"
					placeholder="member Mobile" required
					value="<?php echo $member_row['mobile'];?>" pattern="[0-9]{10}"
					class="form-control" /></td>
			</tr>
			<tr>
				<td align="center" colspan="2"><input type='submit' name='btn-update'
					value='Update' alt='update' class="btn btn-primary" /></td>
			</tr>
		</table>
	</form>
</center>
<?php
} // end of else; the user didn't loggedin
?>

<?php include 'footer.php'; ?>