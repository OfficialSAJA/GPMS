<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

<div class="title-area">
	<h2 class="tittle">
		Group <span> Tasks </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
$task = mysql_query ( "select * FROM tasks WHERE group_id = '$_SESSION[group_id]'" ) or die ( "error task " . mysql_error () );
?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Title</th>
		<th>Deadline</th>
	</tr>
	<?php while ($task_row = mysql_fetch_array ( $task )) {?>
		<tr>
			<td><?php echo $task_row['title']?></td>
			<td><?php echo $task_row['deadline']?></td>
		</tr>
	<?php }?>
</table>

<?php include 'footer.php'; ?>