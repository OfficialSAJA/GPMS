<?php include 'header.php';?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

<?php
// get all information for the notifications
$notifications_query = "SELECT * FROM notifications WHERE group_id = '$_SESSION[group_id]'";
$notifications_result = mysql_query ( $notifications_query ) or die ( 'error : ' . mysql_error () );
?>

 <div class="title-area">
	<h2 class="tittle">
		Group <span> Notifications </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if there is no notification for the student
if (mysql_num_rows ( $notifications_result ) != 0) {
	?>
<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Content</th>
		<th>Date</th>
	</tr>
	<?php while ($notification_row = mysql_fetch_array($notifications_result)) { ?>
		<tr>
			<td><?php echo $notification_row['content']?></td>
			<td><?php echo $notification_row['date']?></td>
		</tr>
	<?php }?>
</table>
<?php }?>

<?php include 'footer.php';?>