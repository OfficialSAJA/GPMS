<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	$file = $_FILES ["proposal_file"] ["name"];
	
	if (($_FILES ["proposal_file"] ["type"] == "application/pdf") && ($_FILES ["proposal_file"] ["size"] < 2000000)) {
		// if there is an error in upload files
		if ($_FILES ["proposal_file"] ["error"] > 0) {
			echo "Error: " . $_FILES ["proposal_file"] ["error"] . "<br>";
		} else // there is no errors in uploading files
{
			// save the file in the file folder
			move_uploaded_file ( $_FILES ["proposal_file"] ["tmp_name"], "proposals/" . $_FILES ["proposal_file"] ["name"] );
			
			if (mysql_query ( "UPDATE groups SET proposal_file = '$file' WHERE id = '$_GET[id]'" )) {
				?>

<script>alert('successfully Add the proposal');</script>
<?php
				header ( "REFRESH:0; url=student_show_group.php#content" );
			} else {
				echo "<script>alert('error while adding proposal');</script>";
			}
		}
	} else {
		?>
<script>alert('error while adding proposal check the file type and size PDF and 2 mega ...');</script>
<?php
	}
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Add <span> Proposal </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post" enctype="multipart/form-data">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td><input type="file" name="proposal_file" required
						class="form-control" /></td>
				</tr>
				<tr>
					<td align="center"><input type='submit' name='btn-signup'
						value='Add Report' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>

<?php include 'footer.php';?>