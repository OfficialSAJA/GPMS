<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	$title = mysql_real_escape_string ( $_POST ['title'] );
	$file = $_FILES ["file"] ["name"];
	
	if (($_FILES ["file"] ["type"] == "application/pdf") && ($_FILES ["file"] ["size"] < 2000000)) {
		// if there is an error in upload files
		if ($_FILES ["file"] ["error"] > 0) {
			echo "Error: " . $_FILES ["file"] ["error"] . "<br>";
		} else // there is no errors in uploading files
		{
			// save the file in the file folder
			move_uploaded_file ( $_FILES ["file"] ["tmp_name"], "files/" . $_FILES ["file"] ["name"] );
			$query = "INSERT INTO files (title, file, group_id) VALUES ('$title', '$file', '$_SESSION[group_id]')";
			$result = mysql_query ($query);
// 			echo $query;
			
			if (mysql_affected_rows () == 1 ) {
				echo "<script>alert('successfully Add the file');</script>";
				header ( "REFRESH:0; url=student_show_group_files.php?id=$_SESSION[group_id]#content" );
			} else {
				echo "<script>alert('error while adding file');</script>";
				header ( "REFRESH:0; url=student_show_group_files.php?id=$_SESSION[group_id]#content" );
			}
		}
	} else {
		echo "<script>alert('error while adding File check the file type PDF and size  2 mega ...');</script>";
	}
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Add <span> File </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post" enctype="multipart/form-data">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td>Title <input type="text" name="title" placeholder="File Title"
						required class="form-control" /></td>
				</tr>
				<tr>
					<td>File <input type="file" name="file" required
						class="form-control" /></td>
				</tr>
				<tr>
					<td align="center"><input type='submit' name='btn-signup'
						value='Add File' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>