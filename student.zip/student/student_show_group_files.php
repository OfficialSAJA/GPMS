<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "student") {
	header ( "Location: index.php" );
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Group <span> files </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
$file = mysql_query ( "select * FROM files WHERE group_id = '$_SESSION[group_id]'" ) or die ( "error file " . mysql_error () );
?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Title</th>
		<th>Date</th>
		<th>File</th>
	</tr>
	<?php while ($file_row = mysql_fetch_array ( $file )) {?>
		<tr>
			<td><?php echo $file_row['title']?></td>
			<td><?php echo $file_row['date']?></td>
			<td><a href="files/<?php echo $file_row['file']?>" target="_blank">Open</a></td>
		</tr>
	<?php }?>
	
	<tr>
		<td align="center" colspan="3"><a href="student_add_group_file.php?id=<?php echo $_SESSION[group_id];?>">Add file</a>
	</tr>
</table>

<?php include 'footer.php'; ?>