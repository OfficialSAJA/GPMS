<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>
<div class="title-area">
	<h2 class="tittle">
		All <span> notifications </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $notifications = mysql_query ( "select * from notifications " ) or die ("error notifications " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Content</th>
		<th>Group ID</th>
		<th></th>
	</tr>
	<?php while ($notification_row = mysql_fetch_array ( $notifications )) { ?>
		<tr>
		<td><?php echo $notification_row['content']?></td>
		<td><?php echo $notification_row['group_id']?></td>
	</tr>
		<?php }?>
		
		<tr>
			<td colspan="3" align="center"><a href="committee_add_notification.php#content">Add new notification</a></td>
		</tr>
		 
</table>

<?php include 'footer.php'; ?>