<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-add'] )) {
	$content = mysql_real_escape_string ( $_POST ['content'] );
	
	if (mysql_query ( "INSERT INTO announcement(content) VALUES('$content')" )) {
		echo "<script>alert('successfully Add the announcement');</script>";
		header ( "REFRESH:0; url=committee_show_announcements.php#content" );
	} else {
		echo "<script>alert('error while adding announcement ...');</script>";
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> Announcement </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<th>Content</th>
					<td><input type="text" name="content"
						placeholder="announcement content" required class="form-control" /></td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-add'
						value=' &nbsp;&nbsp; Add &nbsp;&nbsp; ' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>