<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
	border: 1px solid #ccc;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<p align="right">
	<a href="#" onclick="window.print();"><img src="assets/images/printer.png" width="45" height="45" /></a>
</p>

<div class="title-area">
	<h2 class="tittle">
		Group <span> Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>
<br />

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<?php
	$examiners = mysql_query ("select session.*, examiner1.name AS examiner1_name, examiner2.name AS examiner2_name , examiner3.name AS examiner3_name 
								FROM session
								LEFT JOIN member AS examiner1 ON session.examiner1_id = examiner1.id
								LEFT JOIN member AS examiner2 ON session.examiner2_id = examiner2.id
								LEFT JOIN member AS examiner3 ON session.examiner3_id = examiner3.id
								WHERE session.group_id = '$_GET[id]'") or die ("error examiners " . mysql_error ());
	
	$examiner = mysql_fetch_array ($examiners); ?>
	
	<tr>
		<td colspan="3" align="center"><strong>Examiner 1 : <?php echo $examiner['examiner1_name']; ?></strong></td>
	</tr>
	<tr>
		<th>Evaluation Criteria</th>
		<th>Criteria Category</th>
		<th>Grad</th>
	</tr>
	<?php  $evaluation = mysql_query ( "SELECT evaluation.*, evaluation_criteria.criteria , evaluation_criteria.category 
							FROM evaluation 
							LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id 
							WHERE evaluation.student_id IN ( SELECT id FROM student WHERE group_id = '$_GET[id]' ) 
							AND evaluation.examiner_id = '$examiner[examiner1_id]' 
							AND evaluation.evaluation_criteria_id NOT IN (1, 2, 3, 4)
							GROUP BY evaluation.evaluation_criteria_id" ) or die ( "error student " . mysql_error () ); ?>
	<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) { 
			$status = $evaluation_row['status'];?>
		<tr>
			<td><?php echo $evaluation_row['criteria']?></td>
			<td><?php echo $evaluation_row['category']?></td>
			<td><?php echo $evaluation_row['grade']?></td>
		</tr>
	<?php } // while evaluation ?>
	
	<?php
	// check if the status is pending; show the accept evaluation
	if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
		echo "<tr><td colspan='3' align='center'><a style='btn btn-submit' href='committee_accept_group_evaluation.php?group_id=$_GET[id]&examiner=$examiner[examiner1_id]'>Accept Group Evaluation</a></td></tr>";
	} else {
		if (mysql_num_rows($evaluation) != 0)
			echo "<tr><td colspan='3' align='center'><font color='#008000'><b>Group Evaluation Accepted</b></font></td></tr>";
	}
	?>
	
	<tr>
		<td colspan="3" align="center"><strong>Examiner 2 : <?php echo $examiner['examiner2_name']; ?></strong></td>
	</tr>
	<tr>
		<th>Evaluation Criteria</th>
		<th>Criteria Category</th>
		<th>Grad</th>
	</tr>
	<?php  $evaluation = mysql_query ( "SELECT evaluation.*, evaluation_criteria.criteria , evaluation_criteria.category 
							FROM evaluation 
							LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id 
							WHERE evaluation.student_id IN ( SELECT id FROM student WHERE group_id = '$_GET[id]' ) 
							AND evaluation.examiner_id = '$examiner[examiner2_id]' 
							AND evaluation.evaluation_criteria_id NOT IN (1, 2, 3, 4)
							GROUP BY evaluation.evaluation_criteria_id" ) or die ( "error student " . mysql_error () ); ?>
	<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) {
			$status = $evaluation_row['status'];?>
		<tr>
			<td><?php echo $evaluation_row['criteria']?></td>
			<td><?php echo $evaluation_row['category']?></td>
			<td><?php echo $evaluation_row['grade']?></td>
		</tr>
	<?php } // while evaluation ?>
	
				
	<?php
	// check if the status is pending; show the accept evaluation
	if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
		echo "<tr><td colspan='3' align='center'><a style='btn btn-submit' href='committee_accept_group_evaluation.php?group_id=$_GET[id]&examiner=$examiner[examiner2_id]'>Accept Group Evaluation</a></td></tr>";
	} else {
		if (mysql_num_rows($evaluation) != 0)
			echo "<tr><td colspan='3' align='center'><font color='#008000'><b>Group Evaluation Accepted</b></font></td></tr>";
	}
	?>
	
	<tr>
		<td colspan="3" align="center"><strong>Supervisor : <?php echo $examiner['examiner3_name']; ?></strong></td>
	</tr>
	<tr>
		<th>Evaluation Criteria</th>
		<th>Criteria Category</th>
		<th>Grad</th>
	</tr>
	<?php  $evaluation = mysql_query ( "SELECT evaluation.*, evaluation_criteria.criteria , evaluation_criteria.category 
							FROM evaluation 
							LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id 
							WHERE evaluation.student_id IN ( SELECT id FROM student WHERE group_id = '$_GET[id]' ) 
							AND evaluation.examiner_id = '$examiner[examiner3_id]' 
							AND evaluation.evaluation_criteria_id NOT IN (1, 2, 3, 4)
							GROUP BY evaluation.evaluation_criteria_id" ) or die ( "error student " . mysql_error () ); ?>
	<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) {
			$status = $evaluation_row['status'];?>
		<tr>
			<td><?php echo $evaluation_row['criteria']?></td>
			<td><?php echo $evaluation_row['category']?></td>
			<td><?php echo $evaluation_row['grade']?></td>
		</tr>
	<?php } // while evaluation ?>
				
	<?php
	// check if the status is pending; show the accept evaluation
	if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
		echo "<tr><td colspan='3' align='center'><a style='btn btn-submit' href='committee_accept_group_evaluation.php?group_id=$_GET[id]&examiner=$examiner[examiner3_id]'>Accept Group Evaluation</a></td></tr>";
	} else {
		if (mysql_num_rows($evaluation) != 0)
			echo "<tr><td colspan='3' align='center'><font color='#008000'><b>Group Evaluation Accepted</b></font></td></tr>";
	}
	?>
</table>

<br />
<br />
<div class="title-area">
	<h2 class="tittle">
		Individual <span> Evaluation </span>
	</h2>
	<span class="tittle-line"></span>
</div>
<br />

<?php
$student = mysql_query ( "select * FROM student WHERE group_id = '$_GET[id]'" ) or die ( "error student " . mysql_error () );
?>

<?php while ($student_row = mysql_fetch_array ( $student )) {?>
	<table width="100%" align="center" cellpadding=5 cellspacing=5>
		<tr>
			<td colspan="2" align="center"><strong>Student : <?php echo $student_row['name']; ?></strong></td>
		</tr>
		<?php
			$examiners = mysql_query ("select session.*, examiner1.name AS examiner1_name, examiner2.name AS examiner2_name , examiner3.name AS examiner3_name 
										FROM session
										LEFT JOIN member AS examiner1 ON session.examiner1_id = examiner1.id
										LEFT JOIN member AS examiner2 ON session.examiner2_id = examiner2.id
										LEFT JOIN member AS examiner3 ON session.examiner3_id = examiner3.id
										WHERE session.group_id = '$_GET[id]'") or die ("error examiners " . mysql_error ());
			
			$examiner = mysql_fetch_array ($examiners); ?>
			
			<tr>
				<td colspan="2" align="center"><strong>Examiner 1 : <?php echo $examiner['examiner1_name']; ?></strong></td>
			</tr>
			<tr>
				<th>Evaluation Criteria</th>
				<th>Grad</th>
			</tr>
			<?php  $evaluation = mysql_query ( "select evaluation.*, evaluation_criteria.criteria FROM evaluation LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id WHERE evaluation.student_id = '$student_row[id]' AND evaluation.examiner_id = '$examiner[examiner1_id]' AND evaluation.evaluation_criteria_id IN (1, 2, 3, 4)" ) or die ( "error student " . mysql_error () ); ?>
			<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) { 
					$status = $evaluation_row['status'];?>
				<tr>
					<td><?php echo $evaluation_row['criteria']?></td>
					<td><?php echo $evaluation_row['grade']?></td>
				</tr>
			<?php } // while evaluation ?>
			
			<?php
			// check if the status is pending; show the accept evaluation
			if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
				echo "<tr><td colspan='2' align='center'><a style='btn btn-submit' href='committee_accept_student_evaluation.php?student_id=$student_row[id]&group_id=$_GET[id]&examiner=$examiner[examiner1_id]'>Accept Evaluation</a></td></tr>";
			} else {
				if (mysql_num_rows($evaluation) != 0)
					echo "<tr><td colspan='2' align='center'><font color='#008000'><b>Evaluation Accepted</b></font></td></tr>";
			}
			?>
			
			<tr>
				<td colspan="2" align="center"><strong>Examiner 2 : <?php echo $examiner['examiner2_name']; ?></strong></td>
			</tr>
			<tr>
				<th>Evaluation Criteria</th>
				<th>Grad</th>
			</tr>
			<?php  $evaluation = mysql_query ( "select evaluation.*, evaluation_criteria.criteria FROM evaluation LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id WHERE evaluation.student_id = '$student_row[id]' AND evaluation.examiner_id = '$examiner[examiner2_id]' AND evaluation.evaluation_criteria_id IN (1, 2, 3, 4)" ) or die ( "error student " . mysql_error () ); ?>
			<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) {
					$status = $evaluation_row['status'];?>
				<tr>
					<td><?php echo $evaluation_row['criteria']?></td>
					<td><?php echo $evaluation_row['grade']?></td>
				</tr>
			<?php } // while evaluation ?>
			
						
			<?php
			// check if the status is pending; show the accept evaluation
			if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
				echo "<tr><td colspan='2' align='center'><a style='btn btn-submit' href='committee_accept_student_evaluation.php?student_id=$student_row[id]&group_id=$_GET[id]&examiner=$examiner[examiner2_id]'>Accept Evaluation</a></td></tr>";			
			} else {
				if (mysql_num_rows($evaluation) != 0)
					echo "<tr><td colspan='2' align='center'><font color='#008000'><b>Evaluation Accepted</b></font></td></tr>";
			}
			?>
			
			<tr>
				<td colspan="2" align="center"><strong>Supervisor : <?php echo $examiner['examiner3_name']; ?></strong></td>
			</tr>
			<tr>
				<th>Evaluation Criteria</th>
				<th>Grad</th>
			</tr>
			<?php  $evaluation = mysql_query ( "select evaluation.*, evaluation_criteria.criteria FROM evaluation LEFT JOIN evaluation_criteria ON evaluation_criteria.id = evaluation.evaluation_criteria_id WHERE evaluation.student_id = '$student_row[id]' AND evaluation.examiner_id = '$examiner[examiner3_id]' AND evaluation.evaluation_criteria_id IN (1, 2, 3, 4)" ) or die ( "error student " . mysql_error () ); ?>
			<?php while ($evaluation_row = mysql_fetch_array ($evaluation)) {
					$status = $evaluation_row['status'];?>
				<tr>
					<td><?php echo $evaluation_row['criteria']?></td>
					<td><?php echo $evaluation_row['grade']?></td>
				</tr>
			<?php } // while evaluation ?>
						
			<?php
			// check if the status is pending; show the accept evaluation
			if (mysql_num_rows($evaluation) != 0 && $status == "Pending") {
				echo "<tr><td colspan='2' align='center'><a style='btn btn-submit' href='committee_accept_student_evaluation.php?student_id=$student_row[id]&group_id=$_GET[id]&examiner=$examiner[examiner3_id]'>Accept Evaluation</a></td></tr>";
			} else {
				if (mysql_num_rows($evaluation) != 0)
					echo "<tr><td colspan='2' align='center'><font color='#008000'><b>Evaluation Accepted</b></font></td></tr>";
			}
			?>
	</table>
	<br/>
<?php }?>
<br/>
<br/>
<?php include 'footer.php'; ?>