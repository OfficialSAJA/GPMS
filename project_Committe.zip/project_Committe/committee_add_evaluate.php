<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-add'] )) {
	$criteria = mysql_real_escape_string ( $_POST ['criteria'] );
	$max_grade = mysql_real_escape_string ( $_POST ['max_grade'] );
	$supervisor = mysql_real_escape_string ( $_POST ['supervisor'] );
	$examiner = mysql_real_escape_string ( $_POST ['examiner'] );
	$active = mysql_real_escape_string ( $_POST ['active'] );
	$category = mysql_real_escape_string ( $_POST ['category'] );
	
	$query = "INSERT INTO evaluation_criteria (criteria, max_grade, supervisor, examiner, active, category) VALUES('$criteria', '$max_grade', '$supervisor', '$examiner', '$active', '$category')";
	$result = mysql_query ( $query ) or die ( "error add criteria " . mysql_error () );
	if (mysql_affected_rows () == 1) {
		echo "<script>alert('successfully Add the criteria');</script>";
		header ( "REFRESH:0; url=committee_show_evaluate_criteria.php#criteria" );
	} else {
		echo "<script>alert('error while adding criteria...');</script>";
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> Evaluate Criteria </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<th>Criteria</th>
					<td><input type="text" name="criteria" required class="form-control" /></td>
				</tr>
				<tr>
					<th>Max Grade</th>
					<td><input type="number" min="1" name="max_grade" class="form-control" /></td>
				</tr>
				<tr>
					<th>Supervisor</th>
					<td><input type="radio" name="supervisor" value="yes"
						checked="checked" />Yes &nbsp;&nbsp;&nbsp;&nbsp; <input
						type="radio" name="supervisor" value="no" />No</td>
				</tr>
				<tr>
					<th>Examiner</th>
					<td><input type="radio" name="examiner" value="yes"
						checked="checked" />Yes &nbsp;&nbsp;&nbsp;&nbsp; <input
						type="radio" name="examiner" value="no" />No</td>
				</tr>
				<tr>
					<th>Active</th>
					<td><input type="radio" name="active" value="yes" checked />Yes
						&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="active" value="no" />No
					</td>
				</tr>
				<tr>
					<th>Category</th>
					<td>
						<select name="category" class="form-control">
							<option value="report" >report</option>
							<option value="presentation" >presentation</option>
							<option value="demo" >demo</option>
							<option value="individual" >individual</option>
						</select>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-add'
						value=' &nbsp;&nbsp; Add &nbsp;&nbsp; ' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>