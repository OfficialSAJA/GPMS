<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<div class="title-area">
	<h2 class="tittle">
		Evaluations <span> Criteria </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $evaluates = mysql_query ( "select * FROM evaluation_criteria" ) or die ("error evaluates " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Criteria</th>
		<th>Max Grade</th>
		<th>Supervisor</th>
		<th>Examiner</th>
		<th>Category</th>
		<th>Active</th>
		<th></th>
	</tr>
	<?php while ($evaluate_row = mysql_fetch_array ( $evaluates )) { ?>
		<tr>
		<td><?php echo $evaluate_row['criteria']?></td>
		<td><?php echo $evaluate_row['max_grade']?></td>
		<td><?php echo $evaluate_row['supervisor']?></td>
		<td><?php echo $evaluate_row['examiner']?></td>
		<td><?php echo $evaluate_row['category']?></td>
		<td><?php echo $evaluate_row['active']?></td>
		<td>
			<a href="committee_edit_evaluate.php?id=<?php echo $evaluate_row['id']?>#content">Edit</a> | 
			<a href="committee_delete_evaluate.php?id=<?php echo $evaluate_row['id']?>#content">Delete</a> 
		</td>
	</tr>
		<?php }?>
		<tr>
			<td align="center" colspan="7"><a href="committee_add_evaluate.php">Add New Evaluate Criteria</a></td>
		</tr>
</table>

<?php include 'footer.php'; ?>