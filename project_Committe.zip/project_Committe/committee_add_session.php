<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
} ?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	// get the supervisor of the group to make him the supervisor 3
	$supervisor = mysql_query ("SELECT supervisor_id FROM groups WHERE id = '$_POST[group_id]'");
	$supervisor_row = mysql_fetch_array ($supervisor);
	
	$name = mysql_real_escape_string ( $_POST ['name'] );
	$group_id = mysql_real_escape_string ( $_POST ['group_id'] );
	$examiner1_id = mysql_real_escape_string ( $_POST ['examiner1_id'] );
	$examiner2_id = mysql_real_escape_string ( $_POST ['examiner2_id'] );
	$examiner3_id = mysql_real_escape_string ( $supervisor_row['supervisor_id'] );
	$date = mysql_real_escape_string ( $_POST ['date'] );
	
	$check = mysql_query ( "SELECT * FROM session WHERE group_id = '$group_id'" );
	if (mysql_num_rows ( $check ) != 0) { ?>
<script>alert('This group_id registerd before in session');</script>
<?php
	} else {
		if (mysql_query ( "INSERT INTO session (name, group_id, examiner1_id, examiner2_id, examiner3_id, date ) VALUES( '$name', '$group_id', '$examiner1_id', '$examiner2_id', '$examiner3_id', '$date')" )) { ?>
			
			<script>alert('successfully Add the session');</script>
			<?php header ( "REFRESH:0; url=committee_show_sessions.php#content" );?>
<?php
		} else {
			?>
<script>alert('error while adding session ...');</script>
<?php
		}
	}
}
?>

<?php 
$members = mysql_query ( "select * FROM member WHERE type = 'examiner'" ) or die ("error members " . mysql_error());
$groups = mysql_query ( "select * FROM groups" ) or die ("error groups " . mysql_error());
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> Session </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td>Group ID</td>
					<td><select name="group_id" class="form-control">
							<?php while ($group = mysql_fetch_array ($groups)) { ?>
								<option value="<?php echo $group['id'];?>"><?php echo $group['id'] . ' - ' . $group['project_title'];?></option>
							<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Name </td><td><input type="text" name="name" placeholder="session Name"
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td>Date </td><td><input type="date" name="date" placeholder="session Date" min="<?php echo date ('Y-m-d');?>" 
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td>Examinar1</td>
					<td>
						<select name="examiner1_id" class="form-control">
							<?php while ($member = mysql_fetch_array ($members)) { ?>
								<option value="<?php echo $member['id'];?>"><?php echo $member['name'];?></option>
							<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<td>Examinar2</td>
					<td>
						<select name="examiner2_id" class="form-control">
							<?php 
							mysql_data_seek ($members, 0);	// return to zero row
							while ($member = mysql_fetch_array ($members)) { ?>
								<option value="<?php echo $member['id'];?>"><?php echo $member['name'];?></option>
							<?php } ?>
						</select>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-signup'
						value='Add Session'  class="btn btn-primary"/></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<br/>
<br/>
<br/>
<?php include 'footer.php';?>