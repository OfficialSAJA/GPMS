<?php include 'header.php'; ?>

<div class="title-area">
	<h2 class="tittle">
		Assign <span> supervisor to group </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-update'] )) {
	$supervisor_id = mysql_real_escape_string ( $_POST ['supervisor_id'] );
	$id = mysql_real_escape_string ( $_GET ['id'] );
	
	if (mysql_query ( "UPDATE groups SET supervisor_id = '$supervisor_id' WHERE id = '$_GET[id]'" )) {
		?>
<script>alert('successfully assigned ');</script>
<?php header ( "REFRESH:0; url=committee_show_groups.php" );?>
<?php
	} else {
		?>
<script>alert('error while assign supervisor to group ...');</script>
<?php header ( "REFRESH:0; url=committee_show_groups.php" );?>
<?php
	}
}
?>

<?php $members = mysql_query ( "select * FROM member WHERE type = 'supervisor'" ) or die ("error members " . mysql_error()); ?>

<center>
	<form method="post">
		<table align="center" width="50%" border="0" id="form_table">
			<tr>
				<td>Supervisor : 
					<select name="supervisor_id" class="form-control">
						<?php while ($member_row = mysql_fetch_array ( $members )) { ?>
							<option value="<?php echo $member_row['id'];?>"><?php echo $member_row['name'];?></option>
						<?php } ?>
					</select>
				</td>
			</tr>
			<tr>
				<td align="center"><input type='submit' name='btn-update'
					value='Update' alt='update' class="btn btn-primary" /></td>
			</tr>
		</table>
	</form>
</center>
<br/>
<br/>
<br/>
<?php include 'footer.php'; ?>