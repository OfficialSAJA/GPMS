<?php include 'header.php'; ?>

<div class="title-area">
	<h2 class="tittle">
		Archive <span> Project </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}

if (isset ( $_GET ['id'] )) {
	$id = mysql_real_escape_string ( $_GET ['id'] );
	
	if (mysql_query ( "UPDATE groups SET archived = 'Yes' WHERE id = '$_GET[id]'" )) {
		?>
<script>alert('successfully archived ');</script>
<?php header ( "REFRESH:0; url=committee_show_groups.php" );?>
<?php
	} else {
		?>
<script>alert('error while archive project ...');</script>
<?php header ( "REFRESH:0; url=committee_show_groups.php" );?>
<?php
	}
}
?>

<br/>
<br/>
<br/>
<?php include 'footer.php'; ?>