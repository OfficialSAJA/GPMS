<?php include 'header.php'; ?>

 <div class="title-area">
	<h2 class="tittle">
		Edit <span> student </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-update'] )) {
	$group_id = mysql_real_escape_string ( $_POST ['group_id'] );
	$name = mysql_real_escape_string ( $_POST ['name'] );
	$uname = mysql_real_escape_string ( $_POST ['uname'] );
	$email = mysql_real_escape_string ( $_POST ['email'] );
	$mobile = mysql_real_escape_string ( $_POST ['mobile'] );
	$upass = (mysql_real_escape_string ( $_POST ['pass'] ));
	$name = (mysql_real_escape_string ( $_POST ['name'] ));
	
	if (mysql_query ( "UPDATE student SET group_id = '$group_id', name = '$name', username = '$uname', password = '$upass', email = '$email', mobile = '$mobile' WHERE id = $_GET[id]" )) {
		?>
<script>alert('successfully updated ');</script>
<?php header ( "REFRESH:0; url=committee_show_students.php#content" );?>
<?php
	} else {
		?>
<script>alert('error while updating user data ...');</script>
<?php
	}
}
?>

<?php
// if the user is loggedin
$query = "SELECT * FROM student WHERE id = $_GET[id]";
$member_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$member_row = mysql_fetch_array ( $member_result );

if (mysql_num_rows ( $member_result ) == 1) {
	?>
<center>
	<form method="post">
		<table align="center" width="50%" border="0" id="form_table">
			<tr>
				<td>Group ID : <input type="text" name="group_id"
					placeholder="student Group ID" required
					value="<?php echo $member_row['group_id'];?>" class="form-control"></td>
			</tr>
			<tr>
				<td>Name : <input type="text" name="name"
					placeholder="student username" required
					value="<?php echo $member_row['name'];?>" class="form-control"></td>
			</tr>
			<tr>
				<td>Username : <input type="text" name="uname"
					placeholder="student username" required
					value="<?php echo $member_row['username'];?>" class="form-control"></td>
			</tr>
			<tr>
				<td>Email : <input type="email" name="email"
					placeholder="student Email" required
					value="<?php echo $member_row['email'];?>" class="form-control" /></td>
			</tr>
			<tr>
				<td>Password : <input type="password" name="pass"
					placeholder="student Password" required
					value="<?php echo $member_row['password'];?>" class="form-control" /></td>
			</tr>
			<tr>
				<td>Mobile : <input type="text" name="mobile"
					placeholder="student Mobile" required
					value="<?php echo $member_row['mobile'];?>" pattern="[0-9]{10}"
					class="form-control" /></td>
			</tr>
			<tr>
				<td align="center"><input type='submit' name='btn-update'
					value='Update' alt='update' class="btn btn-primary" /></td>
			</tr>
		</table>
	</form>
</center>
<?php
} // end of else; the user didn't loggedin
?>
<br/>
<br/>
<br/>
<?php include 'footer.php'; ?>