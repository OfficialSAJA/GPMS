<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
// delete the evaluation_criteria
mysql_query ( "DELETE FROM evaluation_criteria WHERE id = $_GET[id]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysql_affected_rows () == 1) {
	echo "<script>alert('successfully deleted ');</script>";
	
	header ( "REFRESH:0; url=committee_show_evaluate_criteria.php#content" );
} else {
	echo "<script>alert('Error While Delete');</script>";
	header ( "REFRESH:0; url=committee_show_evaluate_criteria.php#content" );
}
?>

<?php include 'footer.php';?>