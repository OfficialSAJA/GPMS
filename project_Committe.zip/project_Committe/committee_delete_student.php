<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
// delete the student
mysql_query ( "DELETE FROM student WHERE id = $_GET[id]" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysql_affected_rows () == 1) {
	echo "<script>alert('successfully deleted ');</script>";
	
	header ( "REFRESH:0; url=committee_show_students.php#content" );
} else {
	echo "<script>alert('Error While Delete');</script>";
	header ( "REFRESH:0; url=committee_show_students.php#content" );
}
?>

<?php include 'footer.php';?>