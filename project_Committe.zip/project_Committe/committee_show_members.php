<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>
<div class="title-area">
	<h2 class="tittle">
		All <span> members </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $members = mysql_query ( "select * FROM member" ) or die ("error members " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Name</th>
		<th>Username</th>
		<th>Email</th>
		<th>Mobile</th>
		<th>Type</th>
		<th></th>
	</tr>
	<?php while ($member_row = mysql_fetch_array ( $members )) { ?>
		<tr>
		<td><?php echo $member_row['name']?></td>
		<td><?php echo $member_row['username']?></td>
		<td><?php echo $member_row['email']?></td>
		<td><?php echo $member_row['mobile']?></td>
		<td><?php echo $member_row['type']?></td>
		<td>
			<a href="committee_edit_member.php?id=<?php echo $member_row['id']?>#content">Edit</a>
			&nbsp; 
			<a href="committee_delete_member.php?id=<?php echo $member_row['id']?>#content">Delete</a>
		</td>
	</tr>
		<?php }?>

		<tr>
			<td colspan="6" align="center"><a href="committee_add_member.php#content">Add new member</a></td>
		</tr>		 
</table>

<?php include 'footer.php'; ?>