<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-add'] )) {
	$criteria = mysql_real_escape_string ( $_POST ['criteria'] );
	$max_grade = mysql_real_escape_string ( $_POST ['max_grade'] );
	$supervisor = mysql_real_escape_string ( $_POST ['supervisor'] );
	$examiner = mysql_real_escape_string ( $_POST ['examiner'] );
	$active = mysql_real_escape_string ( $_POST ['active'] );
	$category = mysql_real_escape_string ( $_POST ['category'] );

	$query = "UPDATE evaluation_criteria SET category = '$category', active = '$active', criteria = '$criteria', max_grade = '$max_grade', supervisor = '$supervisor', examiner = '$examiner' WHERE id = $_GET[id]";
	$result = mysql_query ( $query ) or die ( "error update criteria " . mysql_error () );
	if (mysql_affected_rows () == 1) {
		echo "<script>alert('successfully update the criteria');</script>";
		header ( "REFRESH:0; url=committee_show_evaluate_criteria.php#criteria" );
	} else {
		echo "<script>alert('error while updating criteria...');</script>";
	}
}
?>


 <div class="title-area">
	<h2 class="tittle">
		Edit <span> Evaluate Criteria </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />

<?php
$query = "SELECT * FROM evaluation_criteria WHERE id = $_GET[id]";
$evaluate_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$evaluate_row = mysql_fetch_array ( $evaluate_result );

if (mysql_num_rows ( $evaluate_result ) == 1) {
	?>

<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<th>Criteria</th>
					<td><input type="text" name="criteria" required class="form-control"
						value="<?php echo $evaluate_row['criteria'];?>" /></td>
				</tr>
				<tr>
					<th>Max Grade</th>
					<td><input type="number" min="1" name="max_grade" class="form-control" value="<?php echo $evaluate_row['max_grade'];?>" required /></td>
				</tr>
				<tr>
					<th>Supervisor</th>
					<td><input type="radio" name="supervisor" value="yes"
						<?php if ($evaluate_row['supervisor'] == "yes") { echo "checked"; }?> />Yes
						&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="supervisor"
						value="no"
						<?php if ($evaluate_row['supervisor'] == "no") { echo "checked"; }?> />No</td>
				</tr>
				<tr>
					<th>Examiner</th>
					<td><input type="radio" name="examiner" value="yes"
						<?php if ($evaluate_row['examiner'] == "yes") { echo "checked"; }?> />Yes
						&nbsp;&nbsp;&nbsp;&nbsp; <input type="radio" name="examiner"
						value="no"
						<?php if ($evaluate_row['examiner'] == "no") { echo "checked"; }?> />No</td>
				</tr>
				<tr>
					<th>Active</th>
					<td><input type="radio" name="active" value="yes" <?php if ($evaluate_row['active'] == "yes") { echo "checked"; }?> />Yes
						&nbsp;&nbsp;&nbsp;&nbsp; 
						<input type="radio" name="active" value="no" <?php if ($evaluate_row['active'] == "no") { echo "checked"; }?> />No
					</td>
				</tr>
				<tr>
					<th>Category</th>
					<td>
						<select name="category" class="form-control">
							<option value="report" <?php if ($evaluate_row['category'] == "report") { echo "selected"; }?>>report</option>
							<option value="presentation" <?php if ($evaluate_row['category'] == "presentation") { echo "selected"; }?>>presentation</option>
							<option value="demo" <?php if ($evaluate_row['category'] == "demo") { echo "selected"; }?>>demo</option>
							<option value="individual" <?php if ($evaluate_row['category'] == "individual") { echo "selected"; }?>>individual</option>
						</select>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-add'
						value=' &nbsp;&nbsp; Update &nbsp;&nbsp; ' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php }?>
<?php include 'footer.php';?>