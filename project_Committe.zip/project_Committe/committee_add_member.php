<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
} ?>

<?php
if (isset ( $_POST ['btn-signup'] )) {
	$uname = mysql_real_escape_string ( $_POST ['uname'] );
	$name = mysql_real_escape_string ( $_POST ['name'] );
	$email = mysql_real_escape_string ( $_POST ['email'] );
	$mobile = mysql_real_escape_string ( $_POST ['mobile'] );
	$upass =  mysql_real_escape_string ( $_POST ['pass'] ) ;
	$type = mysql_real_escape_string ( $_POST ['type'] );
	
	$check = mysql_query ( "SELECT * FROM member WHERE username = '$uname' OR email = '$email'" );
	if (mysql_num_rows ( $check ) != 0) {
		?>
<script>alert('This username or email registerd before');</script>
<?php
	} else {	
		if (mysql_query ( "INSERT INTO member (name, username,email,password, mobile, type) VALUES( '$name', '$uname','$email','$upass', '$mobile', '$type')" )) { ?>
			
			<script>alert('successfully Add the member');</script>
			<?php header ( "REFRESH:0; url=committee_show_members.php#content" );?>
<?php
		} else {
			?>
<script>alert('error while adding member ...');</script>
<?php
		}
	}
}
?>

<div class="title-area">
	<h2 class="tittle">
		Add <span> New member </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<td><input type="text" name="name" placeholder="member Name"
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td><input type="text" name="uname" placeholder="member User Name"
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td><input type="email" name="email" placeholder="member Email"
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td><input type="password" name="pass" placeholder="member Password"
						required  class="form-control"/></td>
				</tr>
				<tr>
					<td><input type="text" name="mobile" placeholder="member Mobile" class="form-control"
						required pattern="[0-9]{10}" /></td>
				</tr>
				<tr>
					<td><select name="type" class="form-control">
							<option value="supervisor">Supervisor</option>
							<option value="examiner">Examiner</option>
					</select>
					</td>
				</tr>
				<tr>
					<td align="center"><input type='submit' name='btn-signup'
						value='Add member'  class="btn btn-primary"/></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<br/>
<br/>
<br/>
<?php include 'footer.php';?>