<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
// update evaluation
mysql_query ( "UPDATE evaluation SET status = 'Accepted' WHERE student_id IN (SELECT id FROM student WHERE group_id = '$_GET[group_id]') AND examiner_id = $_GET[examiner] AND evaluation_criteria_id NOT IN (1, 2, 3, 4)" ) or die ( 'error ' . mysql_error () );

// if there is affected rows in the database;
if (mysql_affected_rows () != 0) {
	echo "<script>alert('successfully accepte the group evaluation ');</script>";
	
	header ( "REFRESH:0; url=committee_show_group_evaluation.php?id=$_GET[group_id]" );
} else {
	echo "<script>alert('Error While Accept group evaluation ');</script>";
	header ( "REFRESH:0; url=committee_show_group_evaluation.php?id=$_GET[group_id]" );
}
?>

<?php include 'footer.php';?>