<?php include 'header.php'; ?>

 <div class="title-area">
	<h2 class="tittle">
		Edit <span> Announcement </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-update'] )) {
	$content = mysql_real_escape_string ( $_POST ['content'] );
	
	if (mysql_query ( "UPDATE announcement SET content = '$content' WHERE id = $_GET[id]" )) {
		?>
<script>alert('successfully updated ');</script>
<?php
	} else {
		?>
<script>alert('error while updating announcement data ...');</script>
<?php
	}
}
?>

<?php
// if the user is loggedin
$query = "SELECT * FROM announcement WHERE id = $_GET[id]";
$announcement_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$announcement_row = mysql_fetch_array ( $announcement_result );

if (mysql_num_rows ( $announcement_result ) == 1) {
	?>
<center>
	<form method="post">
		<table align="center" width="50%" border="0" id="form_table">
			<tr>
				<td>content : <input type="text" name="content" placeholder="announcement content"
					required value="<?php echo $announcement_row['content'];?>"
					class="form-control"></td>
			</tr>
			<tr>
				<td align="center"><input type='submit' name='btn-update'
					value='Update' alt='update' class="btn btn-primary" /></td>
			</tr>
		</table>
	</form>
</center>
<?php
} // end of else; the user didn't loggedin
?>

<?php include 'footer.php'; ?>