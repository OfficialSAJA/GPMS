<?php include 'header.php'; ?>

 <div class="title-area">
	<h2 class="tittle">
		Edit <span> Deadline </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}

if (isset ( $_POST ['btn-update'] )) {
	$date = mysql_real_escape_string ( $_POST ['date'] );
	
	if (mysql_query ( "UPDATE deadline SET date = '$date' WHERE id = 1" )) {
		?>
<script>alert('successfully updated ');</script>
<?php
	} else {
		?>
<script>alert('error while updating deadline data ...');</script>
<?php
	}
}
?>

<?php
// if the user is loggedin
$query = "SELECT * FROM deadline WHERE id = 1";
$deadline_result = mysql_query ( $query ) or die ( "can't run query because " . mysql_error () );

$deadline_row = mysql_fetch_array ( $deadline_result );

if (mysql_num_rows ( $deadline_result ) == 1) {
	?>
<center>
	<form method="post">
		<table align="center" width="50%" border="0" id="form_table">
			<tr>
				<td>Date : <input type="date" name="date" placeholder="deadline date"
					required value="<?php echo $deadline_row['date'];?>"
					class="form-control"></td>
			</tr>
			<tr>
				<td align="center"><input type='submit' name='btn-update'
					value='Update' alt='update' class="btn btn-primary" /></td>
			</tr>
		</table>
	</form>
</center>
<?php
} // end of else; the user didn't loggedin
?>

<?php include 'footer.php'; ?>