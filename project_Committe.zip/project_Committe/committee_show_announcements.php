<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>
 <div class="title-area">
	<h2 class="tittle">
		All <span> Announcement </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $announcements = mysql_query ( "select * from announcement " ) or die ("error announcements " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>content</th>
		<th></th>
	</tr>
	<?php while ($announcement_row = mysql_fetch_array ( $announcements )) { ?>
		<tr>
		<td><?php echo $announcement_row['content']?></td>
		<td>
			
			<a href="committee_edit_announcement.php?id=<?php echo $announcement_row['id']?>#content">Edit</a>
			&nbsp;
			<a href="committee_delete_announcement.php?id=<?php echo $announcement_row['id']?>#content">Delete</a>
		</td>
	</tr>
		<?php }?>
		
		<tr>
			<td colspan="2" align="center"><a href="committee_add_announcement.php#content">Add new announcement</a></td>
		</tr>
		 
</table>

<?php include 'footer.php'; ?>