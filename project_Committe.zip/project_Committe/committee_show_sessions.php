<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>
 <div class="title-area">
	<h2 class="tittle">
		All <span> Sessions </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $sessions = mysql_query ( "select session.*, examiner1.name AS examiner1_name, examiner2.name AS examiner2_name , examiner3.name AS examiner3_name 
FROM session
LEFT JOIN member AS examiner1 ON session.examiner1_id = examiner1.id
LEFT JOIN member AS examiner2 ON session.examiner2_id = examiner2.id
LEFT JOIN member AS examiner3 ON session.examiner3_id = examiner3.id " ) or die ("error sessions " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>Session Name</th>
		<th>Session Date</th>
		<th>Group ID</th>
		<th>Examinar 1</th>
		<th>Examinar 2</th>
		<th>Supervisor</th>
		<th></th>
	</tr>
	<?php while ($session_row = mysql_fetch_array ( $sessions )) { ?>
		<tr>
			<td><?php echo $session_row['name']?></td>
			<td><?php echo $session_row['date']?></td>
			<td><?php echo $session_row['group_id']?></td>
			<td><?php echo $session_row['examiner1_name']?></td>
			<td><?php echo $session_row['examiner2_name']?></td>
			<td><?php echo $session_row['examiner3_name']?></td>
			<td>
				<a href="committee_delete_session.php?id=<?php echo $session_row['id']?>#content">Delete</a>
			</td>
		</tr>
	<?php }?>
		<tr>
			<td align="center" colspan="6"><a href="committee_add_session.php">Add New Session</a></td>
		</tr>
</table>

<?php include 'footer.php'; ?>