<?php include 'header.php';?>

<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "committee") {
	header ( "Location: index.php" );
}
?>

<?php
if (isset ( $_POST ['btn-add'] )) {
	$content = mysql_real_escape_string ( $_POST ['content'] );
	$group_id = mysql_real_escape_string ( $_POST ['group_id'] );
	
	if (mysql_query ( "INSERT INTO notifications(content, group_id) VALUES('$content', '$group_id')" )) {
		echo "<script>alert('successfully Add the notification');</script>";
		header ( "REFRESH:0; url=committee_show_notifications.php#content" );
	} else {
		echo "<script>alert('error while adding notification ...');</script>";
	}
}
?>

<?php
// return all groups
$groups = mysql_query ( " SELECT * FROM groups " ) or die ( "error group " . mysql_error () );
?>

<div class="title-area">
	<h2 class="tittle">
		Notification <span> Data </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<center>
	<div id="login-form">
		<form method="post">
			<table align="center" width="50%" border="0" id="form_table">
				<tr>
					<th>Content</th>
					<td>
						<textarea name="content" rows="5" placeholder="notification content" required class="form-control"></textarea>
					</td>
				</tr>
				<tr>
					<th>Group ID</th>
					<td>
						<select name="group_id" class="form-control">
						<?php while ($group_row = mysql_fetch_array ($groups)) {?>
							<option value="<?php echo $group_row['id']; ?>"><?php echo $group_row['id']; ?></option>
						<?php } ?>
					</td>
				</tr>
				<tr>
					<td align="center" colspan="2"><input type='submit' name='btn-add'
						value=' &nbsp;&nbsp; Add &nbsp;&nbsp; ' class="btn btn-primary" /></td>
				</tr>
			</table>
		</form>
	</div>
</center>
<?php include 'footer.php';?>