<?php include 'header.php'; ?>

<style>
td {
	text-align: center;
}

th {
	background-color: #eee;
}
</style>


<?php
// if he not logged in ; redirect to the index page
if ($_SESSION ['user_type'] != "examiner") {
	header ( "Location: index.php" );
}
?>

 <div class="title-area">
	<h2 class="tittle">
		Your <span> Session Groups </span>
	</h2>
	<span class="tittle-line"></span>
</div>

<br />
<?php $groups = mysql_query ( "select groups.*, groups.id AS group_id, student.name AS leader_name  FROM groups LEFT JOIN student ON student.id = groups.leader_id WHERE groups.id IN (SELECT group_id FROM session WHERE examiner1_id = $_SESSION[user_id] OR examiner2_id = $_SESSION[user_id] )" ) or die ("error groups " . mysql_error()); ?>

<table width="100%" align="center" cellpadding=5 cellspacing=5>
	<tr>
		<th>ID</th>
		<th>Title</th>
		<th>Description</th>
		<th>Report File</th>
		<th>Proposal File</th>
		<th>Leader</th>
		<th></th>
	</tr>
	<?php while ($group_row = mysql_fetch_array ( $groups )) { ?>
		<tr>
		<td><?php echo $group_row['id']?></td>
		<td><?php echo $group_row['project_title']?></td>
		<td><?php echo $group_row['project_description']?></td>
		<td>
			<?php 
			// check the report exist 
			if ($group_row['report_file'] != "") {
				echo "<a href='reports/$group_row[report_file]' target='_blank'>Open</a>";
			}  else {
				echo "Not Uploaded";
			} ?>
		</td>
		<td>
			<?php 
			// check the proposal exist 
			if ($group_row['proposal_file'] != "") {
				echo "<a href='proposals/$group_row[proposal_file]' target='_blank'>Open</a>";
			} else {
				echo "Not Uploaded";
			} ?>
		</td>
		<td><?php echo $group_row['leader_name']?></td>
		<td>
			<a href="examiner_show_group_evaluation.php?id=<?php echo $group_row['group_id'];?>">Evaluation</a>
		</td>
		
	</tr>
		<?php }?>
</table>

<?php include 'footer.php'; ?>